/***********************************************************
     Starter code for Assignment 3

     This code was originally written by Jack Wang for
		    CSC418, SPRING 2005

		implements light_source.h

***********************************************************/

#include <cmath>
#include "light_source.h"

void PointLight::shade( Ray3D& ray ) {
	// TODO: implement this function to fill in values for ray.col 
	// using phong shading.  Make sure your vectors are normalized, and
	// clamp colour values to 1.0.
	//
	// It is assumed at this point that the intersection information in ray 
	// is available.  So be sure that traverseScene() is called on the ray 
	// before this function.  


/*
// point of intersection
	auto point = ray.intersection.point;
	// point material
	auto material = *(ray.intersection.mat);


	// light direction
	auto lightDir = (_pos - point);
	lightDir.normalize();
	// normal at point
	auto normal =  ray.intersection.normal;
	// diffuse component. FIXME
	auto diffuseLight = std::max(normal.dot(lightDir), 0.0);
	auto diffuseComponent =  material. diffuse * Colour(diffuseLight, diffuseLight, diffuseLight);
	// specular direction
	auto specularDir = (2.0 * lightDir.dot(normal)*normal - lightDir);
	specularDir.normalize();
	// view dir, is the opposite of ray dir
	auto viewDir = -ray.dir;
	// assert(viewDir.length() == 1);
	// specular component
	auto specularLight = std::pow(std::max(specularDir.dot(viewDir), 0.0), material.specular_exp);
	auto specularComponent = material.specular * Colour(specularLight, specularLight, specularLight);
	// final color, should be added to existing color of the ray
	auto finalColor = (material.ambient + diffuseComponent + specularComponent);
	finalColor.clamp();
	ray.col = ray.col + finalColor;
*/

	Vector3D lightvec = _pos - ray.intersection.point;
	Vector3D reflection = 2 * lightvec.dot(ray.intersection.normal) * ray.intersection.normal - lightvec;
	reflection.normalize();
	Vector3D view = -ray.dir;
	view.normalize();
	Colour lighting = _col_ambient * (ray.intersection.mat)->ambient;
	//ray.col.clamp();
	//std::cout<<"colour of ambient: "<<_col_ambient[0]<<", "<<_col_ambient[1]<<" and "<<_col_ambient[2];
	lightvec.normalize();
	double product = fmax(0.0, lightvec.dot(ray.intersection.normal));
	Colour diffuse_colour = _col_diffuse * (ray.intersection.mat)->diffuse;
	//auto diffuse_shading(product*diffuse_colour[0], product*diffuse_colour[1], product*diffuse_colour[2]);
	lighting = lighting + (product * diffuse_colour);
	//lighting = lighting + diffuse_shading;
	//ray.col.clamp();
	product = std::pow(fmax(0.0, reflection.dot(view)), (ray.intersection.mat)->specular_exp);
	Colour specular_colour = _col_specular * (ray.intersection.mat)->specular;
	lighting = lighting + (product * specular_colour);
	lighting.clamp();
	ray.col = lighting;

}

